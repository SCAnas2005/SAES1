<div class="wrapper"></div>
<footer>
    <p>&copy; 2025 - Département Informatique, IUT Villetaneuse</p>
</footer>